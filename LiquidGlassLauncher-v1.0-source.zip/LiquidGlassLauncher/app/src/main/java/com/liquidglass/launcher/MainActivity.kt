package com.liquidglass.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val apps = mutableListOf<Pair<String, android.graphics.drawable.Drawable>>()
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(238, 245, 255)
        window.navigationBarColor = Color.rgb(238, 245, 255)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 18)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(238,245,255), Color.rgb(248,244,255), Color.rgb(225,239,250))
            )
        }
        val clock = TextView(this).apply {
            text = "Liquid Glass"
            textSize = 30f
            setTextColor(Color.rgb(35,45,65))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        base.addView(clock)
        val subtitle = TextView(this).apply {
            text = "Your crystal-style home"
            textSize = 14f
            setTextColor(Color.rgb(95,105,125))
            setPadding(0, 4, 0, 18)
        }
        base.addView(subtitle)

        val search = EditText(this).apply {
            hint = "Search apps"
            singleLine = true
            textSize = 16f
            setPadding(18, 12, 18, 12)
            background = rounded(Color.WHITE, 38)
        }
        base.addView(search)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
        scroll.addView(list)
        base.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(base)
        loadApps()
        showApps("")
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
        setStroke(1, Color.argb(35, 80, 100, 130))
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        @Suppress("DEPRECATION")
        val results = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        apps.clear()
        results.forEach {
            val label = it.loadLabel(pm).toString()
            apps.add(label to it.loadIcon(pm))
        }
        apps.sortBy { it.first.lowercase() }
    }

    private fun showApps(filter: String) {
        list.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val results = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.loadLabel(pm).toString().contains(filter, true) }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        results.forEach { info ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 10, 14, 10)
                background = rounded(Color.argb(190,255,255,255), 22)
            }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(pm)) }
            row.addView(icon, LinearLayout.LayoutParams(48,48))
            val name = TextView(this).apply {
                text = info.loadLabel(pm); textSize = 16f; setTextColor(Color.rgb(35,45,65))
                setPadding(14,0,0,0)
            }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnClickListener {
                val launch = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) startActivity(launch)
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 8
            list.addView(row, lp)
        }
    }
}
